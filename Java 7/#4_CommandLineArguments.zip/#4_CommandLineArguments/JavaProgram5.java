/* WAP to read Command Line Arguments and print the count */

class JavaProgram5
{
	public static void main(String []args) // "10" "49" "21"
	{
		System.out.println("Java Command Line ArgumentsProgram");

		int n = args.length;
		System.out.println("\n Total Number of Arguments = " + n);
	}
}

// step1: Compile Code using javac command
// javac JavaProgram5.java

// step2: Run Java Program with some arguments
// java JavaProgram5 10 49 21





